﻿using System.Web.UI;

namespace MemoEngine.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}